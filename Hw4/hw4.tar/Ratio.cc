#include <iostream> 
#include "Ratio.h"

using namespace std; 

//https://www.geeksforgeeks.org/c-program-find-gcd-hcf-two-numbers/
long gcd(long a, long b) 
{ 
    if (b == 0) 
        return a; 
    return gcd(b, a % b);  
      
}
//https://www.geeksforgeeks.org/program-to-find-lcm-of-two-numbers/
long lcm(long a, long b){  
    return (a*b)/gcd(a, b);    
}

Ratio::Ratio(long numerator, long denominator){
	if(denominator == 0){ 
		throw runtime_error("Dividing by zero.");	//throw error
	} 

	num = numerator; 
	denom = denominator; 

	auto div = gcd(num, denom);

	num = num / div; 
	denom = denom / div; 
	if(num > 0 && denom < 0){ 
		num = -num; 
		denom = -denom; 
	} 
	frac = num / denom;  	
}
Ratio::Ratio(int numerator, int denominator){
	if(denominator == 0){ 
		throw runtime_error("Dividing by zero.");	//throw error
	}
 
	num = static_cast<long>(numerator); 
	denom = static_cast<long>(denominator);

	
	auto div = gcd(num, denom);

	num = num / div; 
	denom = denom / div; 
	if(num > 0 && denom < 0){ 
		num = -num; 
		denom = -denom; 
	} 
	frac = num / denom; 
}

//copy constructor 
Ratio::Ratio(const Ratio &rhs) : num(rhs.num), denom(rhs.denom){ 

} 
//assignment operaor 
Ratio &Ratio::operator=(const Ratio &rhs){ 
	num = rhs.num; 
	denom = rhs.denom; 
	return *this; 
} 
//destructor
Ratio::~Ratio(){ 
	
}  

//.numerator()
long Ratio::numerator() const{ 
	return num; 
} 

//.numerator(long)
void Ratio::numerator(long numerator){ 
	num = numerator; 
	auto div = gcd(num, denom);
	num = num / div; 
	denom = denom / div; 

}

//.denominator()
long Ratio::denominator() const{ 
	return denom; 
} 

//.denominator(long)
void Ratio::denominator(long denominator){ 
	if(denominator == 0){ 
		//ERROR
	} 
	else{ 
		denom = denominator; 
		auto div = gcd(num, denom);
		num = num / div; 
		denom = denom / div; 
		if(num > 0 && denom < 0){ 
		num = -num; 
		denom = -denom; 
		} 
	} 
} 

//.ratio()
long double Ratio::ratio() const{ 
	long double num1 = static_cast<long double>(num); 
	long double den = static_cast<long double>(denom); 
	return num1 / den; 
} 

//.add(Ratio, ...)  NEEEDSSSS WORK_____________________________________________________________________________________
Ratio Ratio::add(Ratio a, Ratio b, Ratio c, Ratio d, Ratio e, Ratio f, Ratio g, Ratio h) const{ 
	//auto a1 = lcm(this->denominator(), a.denominator());
	long num1; 
	long den; 
	long div; 
	Ratio addfrac(0,1);
	if(a.numerator() || a.denominator()){ 
		den = this->denominator() * a.denominator();
		num1 = (this->numerator() * a.denominator()) + (a.numerator() * this->denominator()); 
		
		div = gcd(num1, den);
		num1 = num1 / div; 
		den = den / div;
		addfrac.num = num1;
		addfrac.denom = den; 
		if(b.numerator() != 0 || b.denominator() != 0){ 
			num1 = (num1 * b.denominator()) + (b.numerator() * den); 
			den = den * b.denominator();
			
			div = gcd(num1, den);
			num1 = num1 / div; 
			den = den / div;
			addfrac.num = num1;
			addfrac.denom = den;
			if(c.numerator() != 0 || c.denominator() != 0){ 
				num1 = (num1 * c.denominator()) + (c.numerator() * den); 
				den = den * c.denominator();
				
				div = gcd(num1, den);
				num1 = num1 / div; 
				den = den / div;
				addfrac.num = num1;
				addfrac.denom = den;
				if(d.numerator() != 0 || d.denominator() != 0){ 
					num1 = (num1 * d.denominator()) + (d.numerator() * den); 
					den = den * d.denominator();
					
					div = gcd(num1, den);
					num1 = num1 / div; 
					den = den / div;
					addfrac.num = num1;
					addfrac.denom = den;
					if(e.numerator() != 0 || e.denominator() != 0){ 
						num1 = (num1 * e.denominator()) + (e.numerator() * den); 
						den = den * e.denominator();
						
						div = gcd(num1, den);
						num1 = num1 / div; 
						den = den / div;
						addfrac.num = num1;
						addfrac.denom = den;
						if(f.numerator() != 0 || f.denominator() != 0){ 
							num1 = (num1 * f.denominator()) + (f.numerator() * den); 
							den = den * f.denominator();
							
							div = gcd(num1, den);
							num1 = num1 / div; 
							den = den / div;
							addfrac.num = num1;
							addfrac.denom = den;
							if(g.numerator() != 0 || g.denominator() != 0){ 
								num1 = (num1 * g.denominator()) + (g.numerator() * den); 
								den = den * g.denominator();
								
								div = gcd(num1, den);
								num1 = num1 / div; 
								den = den / div;
								addfrac.num = num1;
								addfrac.denom = den;	
								if(h.numerator() != 0 || h.denominator() != 0){ 
									num1 = (num1 * h.denominator()) + (h.numerator() * den); 
									den = den * h.denominator();
									
									div = gcd(num1, den);
									num1 = num1 / div; 
									den = den / div;
									addfrac.num = num1;
									addfrac.denom = den;
								}
							}
						}
					}
				}
			}
		}
		return addfrac; 
	}
	/*auto div = gcd(num1, den); 
		
	auto numer = num1 / div; 
	auto denomi = den / div; 
	Ratio addfrac(numer, denomi);*/ 
	return addfrac; 
	
}
//.subtract(Ratio)
Ratio Ratio::subtract(Ratio a) const{ 
	auto subDom = this->denominator() * a.denominator(); 
	auto num1 = (this->numerator() * a.denominator()) - (a.numerator() * this->denominator()); 
	//auto num2 = a.numerator() * this->denominator(); 
	
	auto div = gcd(num1, subDom);
	num1 = num1 / div; 
	subDom = subDom / div; 
	
	Ratio subfrac(num1, subDom);
	return subfrac;   
}
	
//.multiply(Ratio)
Ratio Ratio::multiply(Ratio a) const{ 
	auto num1 = this->numerator() * a.numerator(); 
	auto den = this->denominator() * a.denominator(); 
	
	auto div = gcd(num1, den);

	num1 = num1 / div; 
	den = den / div;
	
	Ratio multfrac(num1, den); 
	return multfrac; 
}

//.divide(Ratio) 
Ratio Ratio::divide(Ratio a) const{ 
	auto num1 = this->numerator() * a.denominator(); 
	auto den = this->denominator() * a.numerator(); 
	
	auto div = gcd(num1, den); 
	
	num1 = num1 / div; 
	den = den / div;
	
	Ratio divfrac(num1, den); 
	return divfrac; 
}

//.compare(Ratio) 
int Ratio::compare(Ratio a) const{ 
	
	if(this->ratio() > a.ratio()){ 
		return 1; 
	} 
	else if(this->ratio() < a.ratio()){ 
		return -1; 
	} 
	else{ 
		return 0; 
	} 
}
//.compare(long double) 
int Ratio::compare(long double a) const{ 
	if(this->ratio()  > a){ 
		return 1; 
	} 
	else if(this->ratio() < a){ 
		return -1; 
	} 
	else{ 
		return 0; 
	} 
	return 0;
} 

//ostream << Ratio
std::ostream &operator<<(std::ostream &stream, const Ratio &val){ 
	return stream << val.numerator() << '/' << val.denominator(); 
}  
//istream >> Ratio
std::istream &operator>>(std::istream &in, Ratio &val) {
    long n, d; 
    char c1; 
    if (in >> n >> c1 && c1=='/' && in >> d)
	val = Ratio(n, d);
    else
	in.setstate(ios::failbit);
    return in;
}









