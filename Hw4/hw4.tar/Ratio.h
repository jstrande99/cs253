#include <iostream> 
#include <stdarg.h>

class Ratio{ 
	public: 
		Ratio(long numerator, long denominator = 1); 
		Ratio(int numerator, int denominator = 1); 
		Ratio(const Ratio &); 
		~Ratio(); 
		Ratio &operator = (const Ratio &); 
		
		long numerator() const; 

		void numerator(long num); 

		long denominator() const;

		void denominator(long denom); 

		long double ratio() const;

		Ratio add(Ratio a, Ratio b = Ratio(0,1), Ratio c = Ratio(0,1), Ratio d = Ratio(0,1), Ratio e = Ratio(0,1), Ratio f = Ratio(0,1), Ratio g = Ratio(0,1), Ratio h = Ratio(0,1)) const; 

		Ratio subtract(Ratio a) const;

		Ratio multiply(Ratio a) const;  
		
		Ratio divide(Ratio a) const;

		int compare(Ratio a) const; 

		int compare(long double a) const; 
		
	private: 
		long num, denom;
		long double frac;  

};
std::ostream &operator<<(std::ostream &, const Ratio &); 
std::istream &operator>>(std::istream &, Ratio &); 
