#include <iostream>
        using namespace std;

        int main() {
            // How many CU students does it take to change a light bulb?
            cout << "Zero because they have call CSU students to do it for them!\n";
            return 0;
        }
