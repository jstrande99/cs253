#include <iostream>
	
int main(){ 
	std::cout << "None their parents change the lights for them.\n";
	return 0;
}
